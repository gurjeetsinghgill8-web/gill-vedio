# GILL VEDIO - Implementation TODO

## Plan overview
Implement full blueprint end-to-end:
- Streamlit UI + pages
- Orchestrator (LLM harness) with model router
- Idea generation + Veo video generation
- Review dashboard (approve/reject)
- Scheduling + social publisher (with safe stubs where real APIs need OAuth secrets)
- Persist everything in existing SQLite DB

## Step-by-step checklist
- [ ] 1) Inspect existing files for integration points (already reviewed blueprint + current modules)
- [x] 2) Create missing core modules:
  - [x] 2.1) `models/llm_router.py`
  - [x] 2.2) `models/veo_client.py`
  - [x] 2.3) `llm_harness.py`
  - [x] 2.4) `idea_generator.py`
  - [x] 2.5) `video_generator.py`
  - [x] 2.6) `review_dashboard.py`
  - [x] 2.7) `social_publisher.py`
  - [x] 2.8) `schedule_manager.py`
- [x] 3) Create Streamlit entrypoint `app.py` + UI pages
- [x] 4) Add minimal `config_manager.py` (wrap `security.py` + user preferences)
- [ ] 5) Wire UI → orchestrator → DB updates for each stage
- [ ] 6) Implement publishing dispatcher with retry + DB publish logs
- [ ] 7) Add scheduler loop using APScheduler (configurable intervals)
- [ ] 8) Add local preview utilities + output folders
- [ ] 9) Update `requirements.txt` if needed
- [ ] 10) Smoke test: run `streamlit run app.py`

